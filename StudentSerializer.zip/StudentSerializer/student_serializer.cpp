#include "student_serializer.hpp"

std::vector<char> StudentSerializer::serialize(const StudentRec& rec)
{
    return std::vector<char>(4);
}

StudentRec StudentSerializer::deserialize(const std::vector<char>& buf)
{
    return { 0, "", 0.0f };
}
